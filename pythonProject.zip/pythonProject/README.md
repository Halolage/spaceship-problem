### Spaceship Rental Problem
This is a Python project that solves the Spaceship Rental Problem. 
The goal of the project is to optimize the profitability of a small rental company with a single spaceship 
to rent by producing a list of contract names maximizing the profit.

### Initialize environment and dependencies
Under Project directory, create virtual environment 

```python -m venv env
```

Install project dependencies
```pip install -r requirements.txt
```

### Start Webserver

```python main.py
```

### Send a POST request to the /spaceship/optimize endpoint with a JSON payload containing the list of contracts:

```
curl --location 'http://localhost:8080/spaceship/optimize' \
--header 'Content-Type: application/json' \
--data '[
    {
        "name": "Contract1",
        "start": 0,
        "duration": 5,
        "price": 10
    },
    {
        "name": "Contract2",
        "start": 3,
        "duration": 7,
        "price": 14
    },
    {
        "name": "Contract3",
        "start": 5,
        "duration": 9,
        "price": 8
    },
    {
        "name": "Contract4",
        "start": 5,
        "duration": 9,
        "price": 7
    }
]'

```
