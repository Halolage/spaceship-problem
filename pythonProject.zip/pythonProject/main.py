from typing import List
from itertools import combinations
from flask import Flask, request, jsonify

app = Flask(__name__)


def optimize_rental_contracts(contracts: List[dict]) -> dict:
    """
    Given a list of rental contracts, returns a dictionary containing the optimal combination
    of contracts that maximizes the total income.
    """
    max_income = 0
    max_path = []
    for i in range(1, len(contracts) + 1):
        for combo in combinations(contracts, i):
            # Check if the combination of contracts has any overlaps
            if has_overlaps(combo):
                continue
            # Calculate the total income of the combination
            income = sum(contract["price"] for contract in combo)
            # Update the optimal combination if necessary
            if income > max_income:
                max_income = income
                max_path = [contract["name"] for contract in combo]
    return {"income": max_income, "path": max_path}


def has_overlaps(contracts: List[dict]) -> bool:
    """
    Given a list of rental contracts, returns True if any of the contracts
    have overlapping rental periods, False otherwise.
    """
    for i in range(len(contracts)):
        for j in range(i + 1, len(contracts)):
            contract1 = contracts[i]
            contract2 = contracts[j]
            if (contract1["start"] <= contract2["start"] < contract1["start"] + contract1["duration"] or
                    contract2["start"] <= contract1["start"] < contract2["start"] + contract2["duration"]):
                return True
    return False


@app.route("/spaceship/optimize", methods=["POST"])
def optimize():
    contracts = request.get_json(force=True)
    result = optimize_rental_contracts(contracts)
    return jsonify(result)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
